import json

class Cliente:
    
   def __init__(self, usuario, edad, contrasena):
      self.usuario= usuario
      self.edad= edad
      self.contrasena= contrasena
   def __str__(self):
          return f"\nGracias por registrarte {self[0]['usuario']}\n"
           
   def dataBase(data):
        with open("clientes.json", "w") as file:
          json.dump(data, file)
          file.write('\n')
    
     
   def ver_informacion():
     with open("clientes.json", "r") as file:
        contactos = file.readlines()
        for contacto in contactos:
            contacto_dict = json.loads(contacto)
            print("\nUsuarios registrados: \n")
        for x in contacto_dict:
            print(f"Nombre: {x['usuario']}")
            print(f"Edad: {x['edad']}")
            print(f"Contraseña: {x['contrasena']}")
            print('\t')
        
        
   def login(usuario, contrasena):
      try:
        with open("clientes.json", "r") as file:
          contactos = file.readlines()
          for contacto in contactos:
              contacto_dict = json.loads(contacto)
          for x in contacto_dict:
              if x['usuario'] == usuario:
                  if x['contrasena']==contrasena:
                      return f"\nBienvenido {usuario} !\n "
                  else:
                      return "\nLa contraseña ingresada no es correcta\n" 
      except:
              print('An exception occurred')
              
   def comprar(carrito):
      total=0
      for product in carrito:
        print(product)
        total+=product['precio']          
      print (f"El total a pagar es de ${total} \n")

