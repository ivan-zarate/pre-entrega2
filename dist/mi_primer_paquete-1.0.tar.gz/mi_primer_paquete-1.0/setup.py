from setuptools import setup

setup(
    name="mi_primer_paquete",
    version=1.0,
    author= "Ivan Zarate",
    description="Primer paquete redistribuible"
)